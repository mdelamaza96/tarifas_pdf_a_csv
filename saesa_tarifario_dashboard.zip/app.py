
# Requisitos previos:
# pip install streamlit PyMuPDF requests pandas

import streamlit as st
import fitz  # PyMuPDF
import requests
import os
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Tarifas SAESA", layout="wide")
st.title("📊 Dashboard Tarifas SAESA")

# === Inputs del usuario ===
col1, col2, col3, col4 = st.columns(4)

with col1:
    mes = st.selectbox("Selecciona el mes", options=[
        "enero", "febrero", "marzo", "abril", "mayo", "junio",
        "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"])

with col2:
    anio = st.number_input("Ingresa el año", min_value=2020, max_value=datetime.now().year, value=datetime.now().year)

with col3:
    comuna = st.text_input("Ingresa tu comuna")

with col4:
    tipo_tarifa = st.text_input("Tipo de tarifa", placeholder="BT1, BT2, etc.")

# Funciones auxiliares
@st.cache_data(show_spinner=False)
def descargar_pdf(mes: str, anio: int) -> str:
    mes_lower = mes.lower()
    url = f"https://www.saesa.cl/media/1dldnwnn/pliego-tarifario-{mes_lower}-{anio}.pdf"
    local_path = f"pliego_{mes_lower}_{anio}.pdf"
    response = requests.get(url)
    if response.status_code == 200:
        with open(local_path, 'wb') as f:
            f.write(response.content)
        return local_path
    else:
        return None

def extraer_cargos(pdf_path: str, comuna: str, tipo_tarifa: str):
    doc = fitz.open(pdf_path)
    data = []
    for page in doc:
        text = page.get_text()
        if comuna.lower() in text.lower() and tipo_tarifa.upper() in text.upper():
            lineas = text.split('\n')
            for i, linea in enumerate(lineas):
                if comuna.lower() in linea.lower() and tipo_tarifa.upper() in linea.upper():
                    for j in range(i, min(i+20, len(lineas))):  # Extrae 20 líneas siguientes
                        if any(x in lineas[j] for x in ["Cargo", "$", "%", "kWh"]):
                            data.append({"Descripción": lineas[j]})
    return data

if mes and anio and comuna and tipo_tarifa:
    with st.spinner("Descargando pliego tarifario..."):
        pdf_path = descargar_pdf(mes, anio)

    if pdf_path:
        st.success("Pliego descargado exitosamente")
        with st.spinner("Buscando información en el documento..."):
            resultados = extraer_cargos(pdf_path, comuna, tipo_tarifa)
            if resultados:
                df_resultados = pd.DataFrame(resultados)
                st.subheader(f"Resultados para {comuna.title()} - Tarifa {tipo_tarifa.upper()}")
                st.dataframe(df_resultados, use_container_width=True)
            else:
                st.warning("No se encontraron datos coincidentes con los criterios ingresados.")
        os.remove(pdf_path)
    else:
        st.error("No se pudo descargar el pliego tarifario. Verifica que el mes y año estén disponibles.")
else:
    st.info("Por favor, completa todos los campos para comenzar.")
